package com.teamrocket;


/**
 * Created by JHXSMatthew on 19/03/2017.
 */
public enum EntryType {
    EXPORT("MerchandiseExports",1), RETAIL("Retail",0);

    private String typeString;
    private int cache;
    EntryType(String str, int cacheId) {
        this.typeString = str;
        this.cache = cacheId;
    }

    public static EntryType parseType(String arg) throws Exception {
        for (EntryType type : values()) {
            if (type.typeString.equals(arg))
                return type;
        }
        throw new Exception(arg);
    }

    public static EntryType parseType(int arg) throws Exception {
        for (EntryType type : values()) {
            if (type.cache == arg)
                return type;
        }
        throw new Exception(String.valueOf(arg));
    }

    public String getTypeString(){
        return typeString;
    }

    public int getCacheKey(){
        return cache;
    }
}
