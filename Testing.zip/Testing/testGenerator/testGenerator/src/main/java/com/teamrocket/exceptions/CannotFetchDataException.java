package com.teamrocket.exceptions;

/**
 * Created by JHXSMatthew on 19/03/2017.
 */
public class CannotFetchDataException extends KnownException {

    public CannotFetchDataException(String str) {
        super(str, false);

    }

}
