package com.teamrocket;

/**
 * Created by JHXSMatthew on 17/03/2017.
 */
public interface HaveID {
    int getId();
}
