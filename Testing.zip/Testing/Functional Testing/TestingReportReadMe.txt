TEAM ROCKET README
— Functional Testing
The testing tool used was Postman. The software can be downloaded from: https://www.getpostman.com/
This is a link to the documentation provided by the app developers: https://www.getpostman.com/docs/
There are 5 files: ABS.postman_collection, Electric Stats API.postman_collection, Rocket Statistics API.postman_collection, Electric Stats API.postman_test_run and Rocket Statistics API.postman_test_run
All of these are in a readable test format, but can be imported into Postman for better usability. To import into Postman, download Postman and click import, and locate the collection file and click on it. Once it has been imported, click on the arrow button next to the collection, which will cause a separate menu to pop out. Clicking on run will open a new window where tests can be run. In this window, click import test run and import the test run file to look at the results.
