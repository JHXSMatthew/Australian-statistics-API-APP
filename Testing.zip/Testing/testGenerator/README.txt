mvn clean install
to compile this 

need:
maven 3
Java 1.8